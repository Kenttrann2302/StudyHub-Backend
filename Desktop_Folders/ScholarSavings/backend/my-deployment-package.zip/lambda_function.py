# this contains 2 AWS Lambda functions that send the otp verification that is generated in AWS DynamoDB and verify the user's otp with the otp from the db that was sent to the user's email

# this contains 2 AWS Lambda functions that send the otp verification that is generated in AWS DynamoDB and verify the user's otp with the otp from the db that was sent to the user's email

'''
DynamoDB Table:
--------------
Table Name: otp_holder
Primary Key: email_id
Sort Key: EXPIRATION_TIME
'''



'''
GENERATE OTP:
-------------
'''
# import libraries
import json
import boto3
import time 
import jwt
from flask import Flask, request
from random import randint

lambda_app = Flask(__name__)

# create a dynamo client
client_dynamo = boto3.resource('dynamodb')

# get the table from AWS 
table = client_dynamo.Table('otp_holder')

# define the expiration time for the OTP Code
default_ttl = 600 # 10 minutes

# an aws lambda function that send a request with an otp to the user's endpoint
def lambda_handler(event, context):
 # get the token from the cookies local storage
 with lambda_app.app_context():
  token = request.cookies.get('token')
  
  # get the secret key from the url string
  secret_key = event['queryStringParameters']['secret_key']
  
  # decode the token and get the user's email_address
  email_id = jwt.decode(token, secret_key, algorithms=['HS256'])['verification_endpoint']

  # generate a 6 digits otp code
  otp_value = randint(100000, 999999)

  # create an entry to send a request
  entry = {
   'email_id' : email_id,
   'OTP' : otp_value,
   'EXPIRATION_TIME' : int(time.time()) + default_ttl
  }

  # put the item into the table
  response=table.put_item(Item=entry)
  
  # render the template with the form for the users to enter the OTP that was sent to their email address
  html_template = '''
   <html>
    <head>
     <title>
      StudyHub Enter OTP Code
     </title>
    </head>
    <body>
     <h1>
      Enter OTP Code
     </h1>
     <p>Please enter a 6 digits code that was sent to your email address.</p>
     <form method='POST'>
      <label for='otp-code'>OTP Code:</label>
      <input type="text" id="otp_code" name="otp_code" required/>
      <br>
      <button type="submit">Submit</button>
     </form>
    </body
   </html>
  '''
  
  render_template_response = {
   "statusCode" : 200,
   "headers" : {
    "Content-Type" : "text/html"
   },
   "body" : html_template
  }

  return render_template_response, response

